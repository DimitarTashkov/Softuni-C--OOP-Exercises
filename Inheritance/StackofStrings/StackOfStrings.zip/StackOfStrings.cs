﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomStack
{
    public class StackOfStrings<T> : Stack<T>
    {
        public bool IsEmpty()
        {
            return Count == 0;
        }

        public Stack<T> AddRange(IEnumerable<T> collection)
        {
            foreach (var item in collection)
            {
                this.Push(item);
            }
            return this;
        }
    }
}
